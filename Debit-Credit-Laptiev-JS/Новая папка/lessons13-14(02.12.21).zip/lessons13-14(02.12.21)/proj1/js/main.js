let student = {
    name: 'Vasya', 
    age: 15,
    phone: 0992223322,
    avgMark: 12,
    rate: 123  
};

console.log(student);

console.log(`имя: ${student.name}`);
console.log(`возраст: ${student.age}`);
console.log(`тел: ${student.phone}`);
console.log(`ср. балл: ${student.avgMark}`);
console.log(`№ в рейт.: ${student.rate}`);

